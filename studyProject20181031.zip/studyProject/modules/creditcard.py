'''
提供银行信用卡的所有功能操作,功能列表详见FunctionalDescription
Date:20181026
Author:AAA
'''
